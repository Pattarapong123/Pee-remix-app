export const toDoItems =[
    {
        id: 1,
        title: "กิจกรรม xxx",
        created: "2024-12-14 09:46:00",
        completed: true
    },
    {
        id: 2,
        title: "กิจกรรม yyy",
        created: "2024-12-14 10:40:00",
        completed: false
    },
    {
        id: 3,
        title: "กิจกรรม zzz",
        created: "2024-12-14 13:00:00",
        completed: false
    },
    {
        id: 4,
        title: "กิจกรรม yyy",
        created: "2024-12-14 10:40:00",
        completed: true
    },
    {
        id: 5,
        title: "กิจกรรม zzz",
        created: "2024-12-14 13:00:00",
        completed: false
    }
];